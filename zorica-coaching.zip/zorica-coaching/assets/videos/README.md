Drop local video files here (matching the `file` names in `js/products.js`) only
if you want the demo checkout confirmation links to open something locally.

For a real launch, don't serve videos from this folder — see
`backend/README.md` for why (file size, and no access control), and host them
on Vimeo/YouTube (unlisted) or cloud storage instead, with the links going in
`backend/products.json`.
