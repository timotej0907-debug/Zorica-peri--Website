Drop local PDF files here (matching the `file` names in `js/products.js`) only
if you want the demo checkout confirmation links to open something locally.

For a real launch, host the PDFs on Google Drive/Dropbox or cloud storage and
put the real links in `backend/products.json` — see `backend/README.md`.
