# Backend: payments + automatic delivery

This is the part of the project that makes "buy the Starter Pack → automatically
get 2 videos and a PDF" actually true, rather than just a design mock-up. It has
to be a real server, because the send has to be triggered by a *verified*
payment (from Stripe), not by a button click in the browser — anyone could
click a button, but only Stripe can tell you a card was actually charged.

## How it works

```
Buyer clicks "Pay securely" on checkout.html
        │
        ▼
Browser calls  POST /api/create-checkout-session
        │
        ▼
Server creates a Stripe Checkout Session, returns its URL
        │
        ▼
Browser redirects to Stripe's own hosted payment page
        │  (card details go straight to Stripe — this server never sees them)
        ▼
Stripe processes the payment, then calls your server:
        POST /api/webhook   (event: checkout.session.completed)
        │
        ▼
Server looks up which product(s) were bought, emails the buyer
their video links + PDF link (and a booking link, for Growth/Transformation)
```

## 1. Before you touch code: where will the videos and PDF actually live?

Don't try to email video files as attachments — most inboxes reject anything
over ~20MB, and a 45-minute video will be much bigger than that. Instead, host
each file somewhere and put the **link** in `products.json`:

- **Videos**: an unlisted/private YouTube or Vimeo link (Vimeo has better
  privacy controls — you can require the exact link and disable search), or a
  signed URL from cloud storage (S3, Backblaze B2, Cloudflare R2).
- **PDF**: a shared link from Google Drive/Dropbox (set to "anyone with the
  link"), or the same cloud storage bucket as the videos.

Update every `url` field in `products.json` in this folder once you have them.
The placeholder `REPLACE-ME` links are exactly that — placeholders.

## 2. Install and configure

```bash
cd backend
npm install
cp .env.example .env
```

Fill in `.env`:
- **Stripe**: create a free account at stripe.com, grab your test secret key
  from the Dashboard → Developers → API keys.
- **SMTP**: any transactional email provider works (Resend, Postmark, Brevo,
  SendGrid all have generous free tiers) — they'll give you a host, port,
  username and password.

## 3. Test locally with Stripe's CLI

```bash
# in one terminal
node server.js

# in another terminal — forwards Stripe's webhook events to your local server
stripe listen --forward-to localhost:4000/api/webhook
```

The `stripe listen` command prints a webhook signing secret (`whsec_...`) —
put that in `STRIPE_WEBHOOK_SECRET` in `.env` for local testing. Then use one
of [Stripe's test card numbers](https://docs.stripe.com/testing) to run a full
purchase through checkout.html and confirm the email arrives.

## 4. Point the front-end at this backend

`js/checkout.js` calls `fetch("/api/create-checkout-session", ...)` — a
relative path. That works automatically if this server serves the front-end
files too (it already does, via `express.static`, so deploying just this
`backend` folder with the rest of the project one level up is the simplest
setup). If you deploy the front-end separately (e.g. on Netlify) and the
backend elsewhere (e.g. on Render), change that fetch URL to your backend's
full domain, and make sure `SITE_URL` in `.env` matches wherever the front-end
actually lives.

## 5. Deploy

Any host that runs a persistent Node process works: Render, Railway, or
Fly.io all have simple free/cheap tiers and support Stripe webhooks out of the
box. (Vercel/Netlify's serverless functions can also run this, but the code
needs light adapting since they don't keep a long-running process — ask if you
want that version.) Once deployed:
- Add the real webhook endpoint URL in the Stripe Dashboard → Developers →
  Webhooks, subscribed to the `checkout.session.completed` event, and copy its
  signing secret into `STRIPE_WEBHOOK_SECRET` on your host.
- Switch your Stripe API keys from test (`sk_test_...`) to live (`sk_live_...`)
  once you're ready to accept real payments.

## Keep the two product lists in sync

`products.json` (here) and `../js/products.js` (front-end) describe the same
three packages on purpose kept separate: the front-end file is what a visitor
sees, and this one is what the server trusts for pricing, so a person editing
prices in browser dev tools can't pay less than the real amount. If you change
a price, name, or package, update both files.

## If you'd rather not run a server at all

Custom code gives you full control, but it's real infrastructure to maintain.
If that's more than you want to take on, a no-code alternative like
**Payhip**, **Gumroad**, or **Podia** does exactly this — checkout plus
automatic file delivery — out of the box, and can usually be embedded as a
"Buy now" button inside `shop.html` in place of the custom cart. Worth
considering if this backend feels like more than you need right now.
