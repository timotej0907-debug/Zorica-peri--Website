/**
 * Zorica Perić — checkout + automatic delivery backend.
 *
 * What this does:
 *   1. POST /api/create-checkout-session — takes the cart from the browser,
 *      looks up REAL prices from products.json (never trusts the browser),
 *      and creates a Stripe-hosted Checkout Session.
 *   2. POST /api/webhook — Stripe calls this the moment a payment actually
 *      succeeds. That's the ONLY trigger for sending the videos/PDF —
 *      a page visit or a button click can never cause a send by itself.
 *
 * See README.md in this folder for setup and deployment steps.
 */

require("dotenv").config();
const fs = require("fs");
const path = require("path");
const express = require("express");
const cors = require("cors");
const Stripe = require("stripe");
const nodemailer = require("nodemailer");

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const PRODUCTS = JSON.parse(fs.readFileSync(path.join(__dirname, "products.json"), "utf8"));

const app = express();
app.use(cors());

/**
 * Stripe webhook — must read the RAW body to verify the signature, so this
 * route is registered before express.json() and given its own raw parser.
 */
app.post("/api/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      req.headers["stripe-signature"],
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    try {
      await deliverPurchase(session);
    } catch (err) {
      // Log loudly — a failed delivery after a successful payment is the
      // one failure mode that actually needs a human to notice quickly.
      console.error("DELIVERY FAILED for session", session.id, err);
    }
  }

  res.json({ received: true });
});

app.use(express.json());
app.use(express.static(path.join(__dirname, ".."))); // serves the front-end files too, if you want one server for both

app.post("/api/create-checkout-session", async (req, res) => {
  try {
    const { items, customer } = req.body;
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "Cart is empty." });
    }

    const line_items = items.map(({ id, qty }) => {
      const product = PRODUCTS.find((p) => p.id === id);
      if (!product) throw new Error(`Unknown product id: ${id}`);
      return {
        price_data: {
          currency: "eur",
          product_data: { name: product.name },
          unit_amount: Math.round(product.price * 100), // Stripe wants cents
        },
        quantity: qty,
      };
    });

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,
      customer_email: customer?.email,
      // metadata travels with the session and comes back on the webhook event,
      // which is how the webhook knows what to deliver and to whom.
      metadata: {
        product_ids: items.map((i) => i.id).join(","),
        customer_name: customer?.name || "",
      },
      success_url: `${process.env.SITE_URL}/checkout.html?success=1`,
      cancel_url: `${process.env.SITE_URL}/checkout.html?canceled=1`,
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

async function deliverPurchase(session) {
  const productIds = (session.metadata.product_ids || "").split(",").filter(Boolean);
  const email = session.customer_details?.email || session.customer_email;
  if (!email) {
    console.error("No customer email on session", session.id);
    return;
  }

  const products = productIds.map((id) => PRODUCTS.find((p) => p.id === id)).filter(Boolean);
  if (products.length === 0) {
    console.error("No matching products for session", session.id, productIds);
    return;
  }

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });

  await transporter.sendMail({
    from: process.env.FROM_EMAIL,
    to: email,
    subject: "Your programme from Zorica Perić",
    html: buildDeliveryEmailHtml(products, session.metadata.customer_name),
  });

  console.log(`Delivered ${products.map((p) => p.id).join(", ")} to ${email}`);
}

function buildDeliveryEmailHtml(products, name) {
  const sections = products
    .map((p) => {
      const videoItems = p.delivery.videos.map((v) => `<li><a href="${v.url}">${v.title}</a></li>`).join("");
      const pdfItem = p.delivery.pdf ? `<li><a href="${p.delivery.pdf.url}">${p.delivery.pdf.title}</a></li>` : "";
      const callItem = p.delivery.call
        ? `<li><a href="${p.delivery.call.schedulingUrl}">${p.delivery.call.title}</a></li>`
        : "";
      return `<h3>${p.name}</h3><ul>${videoItems}${pdfItem}${callItem}</ul>`;
    })
    .join("");

  return `
    <p>Hi${name ? " " + name : ""},</p>
    <p>Thank you for your purchase — here's everything included:</p>
    ${sections}
    <p>Keep this email; the links won't expire. If anything doesn't open, just reply to this address.</p>
    <p>— Zorica</p>
  `;
}

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
