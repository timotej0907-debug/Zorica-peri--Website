/**
 * Product catalog.
 *
 * This is the single source of truth for what's for sale on the site.
 * The shop page, cart drawer, and checkout page all read from PRODUCTS.
 *
 * IMPORTANT: if you add, remove, or reprice a package here, make the same
 * change in backend/products.json — the backend uses its own copy so it
 * never has to trust prices sent from the browser. Keeping the two files
 * in sync is the one manual step in this whole system; see backend/README.md.
 */

const PRODUCTS = [
  {
    id: "starter",
    name: "Starter Pack",
    price: 59,
    tagline: "A first, low-stakes look at how coaching, NLP, and hypnotherapy actually work together.",
    includes: [
      "2 guided video sessions (about 45 minutes total)",
      "1 PDF reflection workbook",
    ],
    delivery: {
      videos: [
        { title: "The Pattern Behind the Habit", file: "starter-video-1.mp4" },
        { title: "Guided Relaxation & Anchor Session", file: "starter-video-2.mp4" },
      ],
      pdf: { title: "Starter Reflection Workbook", file: "starter-workbook.pdf" },
    },
  },
  {
    id: "growth",
    name: "Growth Pack",
    price: 149,
    tagline: "For working through one specific pattern — a habit, a block, a recurring reaction — with some guidance.",
    featured: true,
    includes: [
      "4 guided video sessions",
      "2 PDF workbooks",
      "1 live 30-minute call with Zorica",
    ],
    delivery: {
      videos: [
        { title: "The Pattern Behind the Habit", file: "starter-video-1.mp4" },
        { title: "Guided Relaxation & Anchor Session", file: "starter-video-2.mp4" },
        { title: "Reframing in Real Time", file: "growth-video-3.mp4" },
        { title: "Building a New Response", file: "growth-video-4.mp4" },
      ],
      pdf: { title: "Growth Workbook, Parts 1 & 2", file: "growth-workbook.pdf" },
      call: { title: "Book your 30-minute call", schedulingUrl: "https://calendly.com/REPLACE-ME/30min" },
    },
  },
  {
    id: "transformation",
    name: "Full Transformation",
    price: 349,
    tagline: "A guided six-week path, one to one, for a change you want to actually stick.",
    includes: [
      "6 weekly live sessions with Zorica",
      "Full video library access",
      "Personalized workbook",
      "1 follow-up call, 4 weeks after you finish",
    ],
    delivery: {
      videos: [
        { title: "The Pattern Behind the Habit", file: "starter-video-1.mp4" },
        { title: "Guided Relaxation & Anchor Session", file: "starter-video-2.mp4" },
        { title: "Reframing in Real Time", file: "growth-video-3.mp4" },
        { title: "Building a New Response", file: "growth-video-4.mp4" },
      ],
      pdf: { title: "Personalized Workbook (sent after your first session)", file: "transformation-workbook.pdf" },
      call: { title: "Book your first session", schedulingUrl: "https://calendly.com/REPLACE-ME/intro-session" },
    },
  },
];

function findProduct(id) {
  return PRODUCTS.find((p) => p.id === id);
}

/**
 * Renders the package/pricing cards into any container element.
 * Used on both the home page (preview) and the shop page (full list),
 * so a price or product change here shows up everywhere automatically.
 */
function renderPackages(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = PRODUCTS.map(
    (p) => `
    <div class="package-card ${p.featured ? "featured" : ""}">
      <div>
        <h3 class="package-name">${p.name}</h3>
        <p class="package-tagline">${p.tagline}</p>
      </div>
      <div class="package-price">${formatPrice(p.price)}<sup>/ program</sup></div>
      <ul class="package-includes">
        ${p.includes.map((i) => `<li>${i}</li>`).join("")}
      </ul>
      <button class="btn btn-primary btn-block" onclick="addToCart('${p.id}')">Add to cart</button>
    </div>`
  ).join("");
}
