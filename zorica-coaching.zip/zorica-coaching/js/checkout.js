/**
 * Checkout flow.
 *
 * On submit, this tries POST /api/create-checkout-session (see backend/server.js).
 * If that backend isn't running — which it won't be until you deploy it — the
 * fetch fails and we fall back to a demo confirmation, built from this browser's
 * copy of PRODUCTS, so you can see exactly what a real buyer would receive.
 *
 * Once the backend is deployed, the real flow is:
 *   1. Buyer clicks "Pay securely" → redirected to Stripe's hosted checkout
 *   2. Stripe processes the payment
 *   3. Stripe calls your backend's webhook
 *   4. Your backend emails the buyer their video/PDF links (see backend/server.js)
 * No card details ever touch this site directly.
 */

function renderCheckoutSummary() {
  const body = document.getElementById("checkout-summary-body");
  const totalEl = document.getElementById("checkout-total");
  const formSection = document.getElementById("checkout-form-section");
  if (!body) return;

  const lines = cartLinesWithProducts();
  if (lines.length === 0) {
    body.innerHTML = '<p class="cart-empty">Your cart is empty. <a href="shop.html" style="color:var(--color-accent)">Choose a program first.</a></p>';
    if (formSection) formSection.style.display = "none";
    totalEl.textContent = formatPrice(0);
    return;
  }

  body.innerHTML = lines
    .map(
      (l) => `
    <div class="cart-line">
      <div>
        <div class="cart-line-name">${l.product.name}</div>
        <div class="cart-line-meta">${l.qty} × ${formatPrice(l.product.price)}</div>
      </div>
      <div>${formatPrice(l.product.price * l.qty)}</div>
    </div>`
    )
    .join("");
  totalEl.textContent = formatPrice(cartTotal());
}

function showDemoConfirmation(name, email) {
  const lines = cartLinesWithProducts();
  document.getElementById("checkout-form-section").style.display = "none";
  const conf = document.getElementById("checkout-confirmation");
  conf.style.display = "block";
  conf.innerHTML = `
    <div class="notice info">
      <strong>Demo mode.</strong> No payment backend is connected yet, so nothing was charged.
      This is what ${email || "the buyer"} would receive by email after a real payment —
      see backend/README.md to wire up real payments and automatic delivery.
    </div>
    <div class="notice success mt-lg">
      <h3 style="margin-bottom:0.3rem">Thanks${name ? ", " + name : ""} — here's what's included</h3>
      ${lines
        .map(
          (l) => `
        <p style="margin-bottom:0.4rem;margin-top:1rem"><strong style="color:var(--color-text)">${l.product.name}</strong></p>
        <div class="download-list">
          ${l.product.delivery.videos.map((v) => `<a href="assets/videos/${v.file}" target="_blank" rel="noopener">${v.title} <span class="text-muted">Video</span></a>`).join("")}
          ${l.product.delivery.pdf ? `<a href="assets/files/${l.product.delivery.pdf.file}" target="_blank" rel="noopener">${l.product.delivery.pdf.title} <span class="text-muted">PDF</span></a>` : ""}
          ${l.product.delivery.call ? `<a href="${l.product.delivery.call.schedulingUrl}" target="_blank" rel="noopener">${l.product.delivery.call.title} <span class="text-muted">Booking</span></a>` : ""}
        </div>`
        )
        .join("")}
    </div>
  `;
  localStorage.removeItem(CART_KEY);
  updateCartBadge();
}

document.addEventListener("DOMContentLoaded", () => {
  renderCheckoutSummary();

  document.getElementById("checkout-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = document.getElementById("customer-name").value.trim();
    const email = document.getElementById("customer-email").value.trim();
    const cart = getCart();
    if (cart.length === 0) return;

    const payBtn = document.getElementById("pay-btn");
    payBtn.disabled = true;
    payBtn.textContent = "Processing…";

    try {
      const res = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: cart, customer: { name, email } }),
      });
      if (!res.ok) throw new Error("backend not available");
      const data = await res.json();
      if (!data.url) throw new Error("no checkout url returned");
      window.location.href = data.url; // Stripe-hosted checkout page
    } catch (err) {
      showDemoConfirmation(name, email);
    }
  });
});
