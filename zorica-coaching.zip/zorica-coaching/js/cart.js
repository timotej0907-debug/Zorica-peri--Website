/**
 * Cart: persisted in localStorage under CART_KEY so it survives between
 * pages and visits. Shape: [{ id: "starter", qty: 1 }, ...]
 */

const CART_KEY = "zoricaCart";

function getCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  } catch (e) {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartBadge();
  renderCartDrawer();
  if (typeof renderCartPage === "function") renderCartPage();
  if (typeof renderCheckoutSummary === "function") renderCheckoutSummary();
}

function addToCart(id) {
  const cart = getCart();
  const line = cart.find((i) => i.id === id);
  if (line) {
    line.qty += 1;
  } else {
    cart.push({ id, qty: 1 });
  }
  saveCart(cart);
  openCartDrawer();
}

function removeFromCart(id) {
  saveCart(getCart().filter((i) => i.id !== id));
}

function setQty(id, qty) {
  const cart = getCart();
  const line = cart.find((i) => i.id === id);
  if (!line) return;
  line.qty = Math.max(1, qty);
  saveCart(cart);
}

function cartLinesWithProducts() {
  return getCart()
    .map((line) => ({ ...line, product: findProduct(line.id) }))
    .filter((line) => line.product);
}

function cartTotal() {
  return cartLinesWithProducts().reduce((sum, l) => sum + l.product.price * l.qty, 0);
}

function formatPrice(n) {
  return "€" + n.toFixed(0);
}

function updateCartBadge() {
  const count = getCart().reduce((sum, i) => sum + i.qty, 0);
  document.querySelectorAll("[data-cart-count]").forEach((el) => {
    el.textContent = count;
    el.style.display = count > 0 ? "grid" : "none";
  });
}

/* ---- Drawer (present on every page) ---- */

function openCartDrawer() {
  document.getElementById("cart-drawer")?.classList.add("open");
  document.getElementById("cart-overlay")?.classList.add("open");
}

function closeCartDrawer() {
  document.getElementById("cart-drawer")?.classList.remove("open");
  document.getElementById("cart-overlay")?.classList.remove("open");
}

function renderCartDrawer() {
  const container = document.getElementById("cart-drawer-items");
  if (!container) return;
  const lines = cartLinesWithProducts();

  if (lines.length === 0) {
    container.innerHTML = '<p class="cart-empty">Your cart is empty.</p>';
  } else {
    container.innerHTML = lines
      .map(
        (l) => `
      <div class="cart-line">
        <div>
          <div class="cart-line-name">${l.product.name}</div>
          <div class="cart-line-meta">
            <span class="qty-control">
              <button type="button" aria-label="Decrease quantity" onclick="setQty('${l.id}', ${l.qty - 1})">−</button>
              <span>${l.qty}</span>
              <button type="button" aria-label="Increase quantity" onclick="setQty('${l.id}', ${l.qty + 1})">+</button>
            </span>
            <button type="button" class="remove-line" onclick="removeFromCart('${l.id}')">Remove</button>
          </div>
        </div>
        <div>${formatPrice(l.product.price * l.qty)}</div>
      </div>`
      )
      .join("");
  }

  const foot = document.getElementById("cart-drawer-foot");
  if (foot) {
    foot.innerHTML = `
      <div class="cart-total-row"><span>Total</span><span>${formatPrice(cartTotal())}</span></div>
      <a class="btn btn-primary btn-block" href="checkout.html">Go to checkout</a>
    `;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  renderCartDrawer();

  document.getElementById("cart-toggle")?.addEventListener("click", openCartDrawer);
  document.getElementById("cart-overlay")?.addEventListener("click", closeCartDrawer);
  document.getElementById("cart-drawer-close")?.addEventListener("click", closeCartDrawer);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeCartDrawer();
  });
});
