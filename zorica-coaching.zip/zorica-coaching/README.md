# Zorica Perić — coaching website

A five-page site (Home, About, Programs/Cart, Checkout, Journal) plus a small
backend that automatically emails a buyer their videos and PDF after a real
payment. Plain HTML/CSS/JS front-end — no build step, no framework — so
everything opens and edits directly in VS Code.

## Structure

```
index.html          Home
about.html           About Zorica
shop.html            Programs + full cart
checkout.html        Checkout (order summary, buyer details, payment)
blog.html            Journal listing
posts/               Individual blog post pages (one example included —
                      duplicate it for each new post)
css/style.css        All styling — colors and fonts are CSS variables at the top
js/products.js       The product catalog (edit prices/packages here)
js/cart.js           Cart logic (localStorage-based, works with no backend)
js/checkout.js       Checkout flow + demo confirmation fallback
js/main.js           Mobile nav toggle
assets/              Local placeholders for the demo checkout (see its README)
backend/             Stripe checkout + automatic delivery email server
```

## Running it locally

Because the pages use `fetch` for the checkout API call, open this with a
local server rather than double-clicking the HTML files (a plain `file://`
page will still work for browsing, but the checkout demo fallback is more
reliable over http). Easiest options:

- VS Code: install the **Live Server** extension, right-click `index.html` →
  "Open with Live Server."
- Or, from a terminal in this folder: `npx serve .`

## What works right now, with zero setup

- Every page, all navigation, the mobile menu.
- Add to cart, the slide-in cart drawer, and the full cart table on the
  Programs page — all persisted in the browser via `localStorage`.
- Checkout: fill in the form and click "Pay securely." Since no backend is
  running yet, it falls into a **demo confirmation** showing exactly what a
  real buyer would receive — the two videos and the PDF for the Starter Pack,
  scaled up for the other packages.

## What needs the backend to be real

Actually charging a card and automatically emailing the videos/PDF needs a
server that Stripe can call back — a static site alone can't verify a
payment happened. That's what `backend/` is for. **Start with
`backend/README.md`** — it walks through hosting the video/PDF files
somewhere real, setting up Stripe, and deploying.

If maintaining a server isn't something you want to take on, that README also
covers a no-code alternative (Payhip/Gumroad/Podia) that does the same job.

## Content you should replace before launching

A few things are placeholder content, marked with HTML comments in the files:

- **about.html** — the career timeline, bio, and credentials list are
  generic examples. Replace with Zorica's real background and real
  certifying bodies.
- **index.html** — the three client testimonials are invented for the
  template. Replace with real quotes (with permission), or remove the section.
- **Contact details** — `hello@replace-me.com` appears in the footer of every
  page; find-and-replace it with the real address.
- **Scheduling links** — `js/products.js` and `backend/products.json` both
  have `https://calendly.com/REPLACE-ME/...` placeholders for the Growth and
  Transformation packages' booking links.
- **Newsletter forms** on the Home and Journal pages are just styled UI —
  connect them to an email provider (Mailchimp, Brevo, ConvertKit, etc.) to
  actually collect signups.

## Editing prices or packages

Everything about what's for sale lives in `js/products.js` — name, price,
tagline, what's included, and which videos/PDF get delivered. Change it once
there and it updates the Home page preview, the Programs page, the cart, and
checkout automatically. If you also have the backend running, make the same
change in `backend/products.json` (see that folder's README for why the two
are kept separate).

## Design notes

Colors, fonts, and spacing are all CSS custom properties at the top of
`css/style.css` — change the palette by editing the `:root` block once.
